using UnityEngine;
using HutongGames.PlayMaker;

[ActionCategory("Smooth Moves")]
[Tooltip("Sets the Frames per Second on a Smooth Moves bone animation")]
public class SmoothMoves_SetAnimationFPS : FsmStateAction
{
    [RequiredField]
    [CheckForComponent(typeof(Animation))]
    public FsmOwnerDefault gameObject;
    [RequiredField]
    [UIHint(UIHint.Animation)]
    public FsmString animName;
    public FsmFloat fps = 1f;
    public bool everyFrame;

    public override void Reset()
    {
        gameObject = null;
        animName = null;
        fps = 1f;
        everyFrame = false;
    }

    public override void OnEnter()
    {
        DoSetAnimationSpeed(gameObject.OwnerOption == OwnerDefaultOption.UseOwner ? Owner : gameObject.GameObject.Value);

        if (!everyFrame)
            Finish();
    }

    public override void OnUpdate()
    {
        DoSetAnimationSpeed(gameObject.OwnerOption == OwnerDefaultOption.UseOwner ? Owner : gameObject.GameObject.Value);
    }

    void DoSetAnimationSpeed(GameObject go)
    {
        if (go == null) return;

        SmoothMoves.BoneAnimation boneAnimation = go.GetComponent<SmoothMoves.BoneAnimation>();

        if (boneAnimation == null)
        {
            LogWarning("Missing Smooth Moves bone animation component: " + go.name);
            return;
        }

        SmoothMoves.AnimationStateSM anim = boneAnimation[animName.Value];

        if (anim == null)
        {
            LogWarning("Missing animation: " + animName.Value);
            return;
        }

        anim.fps = fps.Value;
    }
}
