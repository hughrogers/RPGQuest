using UnityEngine;
using HutongGames.PlayMaker;

[ActionCategory("Smooth Moves")]
[Tooltip("Enables/Disables a Smooth Moves Animation on a Game Object.\nAnimation time is paused while disabled. Animation must also have a non zero weight to play.")]
public class SmoothMoves_EnableAnimation : FsmStateAction
{
    [RequiredField]
    [CheckForComponent(typeof(Animation))]
    public FsmOwnerDefault gameObject;

    [RequiredField]
    [UIHint(UIHint.Animation)]
    public FsmString animName;

    [RequiredField]
    public FsmBool enable;

    public FsmBool resetOnExit;

    private SmoothMoves.AnimationStateSM anim;

    public override void Reset()
    {
        gameObject = null;
        animName = null;
        enable = true;
        resetOnExit = false;
    }

    public override void OnEnter()
    {
        DoEnableAnimation(Fsm.GetOwnerDefaultTarget(gameObject));

        Finish();
    }

    void DoEnableAnimation(GameObject go)
    {
        if (go == null)
        {
            return;
        }

        SmoothMoves.BoneAnimation boneAnimation = go.GetComponent<SmoothMoves.BoneAnimation>();

        if (boneAnimation == null)
        {
            LogError("Missing Smooth Moves bone animation component!");
            return;
        }

        anim = boneAnimation[animName.Value];

        if (anim != null)
        {
            anim.enabled = enable.Value;
        }
    }

    public override void OnExit()
    {
        if (resetOnExit.Value && anim != null)
        {
            anim.enabled = !enable.Value;
        }
    }
}
