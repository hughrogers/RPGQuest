using UnityEngine;
using HutongGames.PlayMaker;

[ActionCategory("Smooth Moves")]
[Tooltip("Rewinds the named animation.")]
public class SmoothMoves_RewindAnimation : FsmStateAction
{
    [RequiredField]
    [CheckForComponent(typeof(Animation))]
    public FsmOwnerDefault gameObject;
    [UIHint(UIHint.Animation)]
    public FsmString animName;

    public override void Reset()
    {
        gameObject = null;
        animName = null;
    }

    public override void OnEnter()
    {
        DoRewindAnimation();

        Finish();
    }

    void DoRewindAnimation()
    {
        if (string.IsNullOrEmpty(animName.Value))
        {
            return;
        }

        var go = Fsm.GetOwnerDefaultTarget(gameObject);
        if (go == null)
        {
            return;
        }

        SmoothMoves.BoneAnimation boneAnimation = go.GetComponent<SmoothMoves.BoneAnimation>();

        if (boneAnimation == null)
        {
            LogWarning("Missing Smooth Moves bone animation component: " + go.name);
            return;
        }

        boneAnimation.Rewind(animName.Value);
    }
}
