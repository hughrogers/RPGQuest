using UnityEngine;
using HutongGames.PlayMaker;

[ActionCategory("Smooth Moves")]
[Tooltip("Blends a Smooth Moves Animation towards a Target Weight over a specified Time.\nOptionally sends an Event when finished.")]
public class SmoothMoves_BlendAnimation : FsmStateAction
{
    [RequiredField]
    [CheckForComponent(typeof(Animation))]
    [Tooltip("The game object to animate.")]
    public FsmOwnerDefault gameObject;

    [RequiredField]
    [UIHint(UIHint.Animation)]
    [Tooltip("The name of the animation to blend.")]
    public FsmString animName;

    [RequiredField]
    [HasFloatSlider(0f, 1f)]
    [Tooltip("Target weight to blend to.")]
    public FsmFloat targetWeight;

    [RequiredField]
    [HasFloatSlider(0f, 5f)]
    [Tooltip("How long should the blend take.")]
    public FsmFloat time;

    [Tooltip("Event to send when the blend has finished.")]
    public FsmEvent finishEvent;

    // TODO: Delayed event doesn't handle speed changes etc.
    // Use Animation isPlaying instead?
    DelayedEvent delayedFinishEvent;

    public override void Reset()
    {
        gameObject = null;
        animName = null;
        targetWeight = 1f;
        time = 0.3f;
        finishEvent = null;
    }

    public override void OnEnter()
    {
        DoBlendAnimation(gameObject.OwnerOption == OwnerDefaultOption.UseOwner ? Owner : gameObject.GameObject.Value);
    }

    public override void OnUpdate()
    {
        if (DelayedEvent.WasSent(delayedFinishEvent))
        {
            Finish();
        }
    }

    void DoBlendAnimation(GameObject go)
    {
        if (go == null)
        {
            return;
        }

        SmoothMoves.BoneAnimation boneAnimation = go.GetComponent<SmoothMoves.BoneAnimation>();

        if (boneAnimation == null)
        {
            LogWarning("Missing Smooth Moves bone animation component on GameObject: " + go.name);
            Finish();
            return;
        }

        SmoothMoves.AnimationStateSM anim = boneAnimation[animName.Value];

        if (anim == null)
        {
            LogWarning("Missing animation: " + animName.Value);
            Finish();
            return;
        }

        var timeValue = time.Value;
        boneAnimation.Blend(animName.Value, targetWeight.Value, timeValue);

        // TODO: doesn't work well with scaled time
        if (finishEvent != null)
        {
            delayedFinishEvent = Fsm.DelayedEvent(finishEvent, anim.length);
        }
        else
        {
            Finish();
        }
    }
}
