using UnityEngine;
using HutongGames.PlayMaker;

[ActionCategory("Smooth Moves")]
[Tooltip("Stops all playing Smooth Moves Animations on a Game Object. Optionally, specify a single Animation to Stop.")]
public class SmoothMoves_StopAnimation : FsmStateAction
{
    [RequiredField]
    [CheckForComponent(typeof(Animation))]
    public FsmOwnerDefault gameObject;
    [Tooltip("Leave empty to stop all playing animations.")]
    [UIHint(UIHint.Animation)]
    public FsmString animName;

    public override void Reset()
    {
        gameObject = null;
        animName = null;
    }

    public override void OnEnter()
    {
        DoStopAnimation();

        Finish();
    }

    void DoStopAnimation()
    {
        GameObject go = Fsm.GetOwnerDefaultTarget(gameObject);
        if (go == null) return;

        SmoothMoves.BoneAnimation boneAnimation = go.GetComponent<SmoothMoves.BoneAnimation>();

        if (boneAnimation == null)
        {
            LogWarning("Missing Smooth Moves bone animation component: " + go.name);
            return;
        }

        boneAnimation.Stop(animName.Value);
    }
}
